class Video < ApplicationRecord
end
