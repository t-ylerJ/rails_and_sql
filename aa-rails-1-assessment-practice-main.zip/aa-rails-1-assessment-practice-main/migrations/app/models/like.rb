class Like < ApplicationRecord
end
