# == Schema Information
#
# Table name: castings
#
#  id         :bigint           not null, primary key
#  actor_id   :bigint           not null
#  movie_id   :bigint           not null
#  ord        :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Casting < ApplicationRecord
  belongs_to :actor
  belongs_to :movie
end
